import {createContext, useContext, useEffect, useState } from "react"
import {onAuthStateChanged, signOut, GoogleAuthProvider, signInWithPopup} from "firebase/auth"
import {auth} from "../firebase"
const AuthContext = createContext();

export const AuthProvider = ({children}) => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            if (user) {
                setUser(user)
            }
        })

        return () => unsubscribe();
    }, [])

    const logout = async () => {
        await signOut(auth);
    }

    // Sign in with Google (web). Requires Google provider enabled in Firebase Console.
    const signInWithGoogle = async () => {
        try {
            const provider = new GoogleAuthProvider();
            const result = await signInWithPopup(auth, provider);
            // result.user will be available and onAuthStateChanged will run as well
            return result.user;
        } catch (error) {
            // Rethrow so callers can show an error message
            throw error;
        }
    }

    return (
        <AuthContext.Provider value={{user, logout, signInWithGoogle}}>
            {children}
        </AuthContext.Provider>
    )
}

export const useAuth = () => useContext(AuthContext);